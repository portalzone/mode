
<style>
</style>
<nav id="sidebar" class='mx-lt-5 bg-dark' >
		
		<div class="sidebar-list">

				<a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span> Home</a>
				<a href="index.php?page=electioncreate" class="nav-item nav-receiving nav-manage_receiving"><span class='icon-field'><i class="fa fa-file-alt"></i></span> Create Election</a>
				<a href="index.php?page=votingcat" class="nav-item nav-receiving nav-manage_receiving"><span class='icon-field'><i class="fa fa-file-alt"></i></span> Election Category</a>
				<a href="index.php?page=result" class="nav-item nav-receiving nav-manage_receiving"><span class='icon-field'><i class="fa fa-coins"></i></span> Election Result</a>
				<a href="index.php?page=party" class="nav-item nav-categories"><span class='icon-field'><i class="fa fa-list"></i></span> Party</a>
				<a href="index.php?page=state" class="nav-item nav-categories"><span class='icon-field'><i class="fa fa-list"></i></span> State</a>
				<a href="index.php?page=lga" class="nav-item nav-product"><span class='icon-field'><i class="fa fa-boxes"></i></span> Local Government</a>
				<a href="index.php?page=ward" class="nav-item nav-supplier"><span class='icon-field'><i class="fa fa-truck-loading"></i></span> Ward</a>
				<a href="index.php?page=polling" class="nav-item nav-customer"><span class='icon-field'><i class="fa fa-user-friends"></i></span> Polling Unit</a>
				
				<?php if($_SESSION['login_type'] == 1): ?>
				<a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
			<?php endif; ?>
		</div>

</nav>
<script>
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>
<?php if($_SESSION['login_type'] != 1): ?>
	<style>
		.nav-item{
			display: none!important;
		}
		.nav-sales ,.nav-home ,.nav-inventory{
			display: block!important;
		}
	</style>
<?php endif ?>