<?php include('db_connect.php');?>

<style>
	.update_default{
		cursor: pointer;
	}
</style>
<div class="container-fluid">
	
	<div class="col-lg-12">
		<div class="row">


			<!-- Table Panel -->
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table class="table table-bordered table-hover">
							<colgroup>
								<col width="5%">
								<col width="25%">
								<col width="30%">
								<col width="10%">
								<col width="10%">
								<col width="20%">
							</colgroup>
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th class="text-center">Title</th>
									<th class="text-center">Descrition</th>
									<th class="text-center">Type</th>
									<th class="text-center">Default</th>
									<th class="text-center">Completed</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 1;
								$vote = $conn->query("SELECT * FROM electionname order by id asc");
								while($row=$vote->fetch_assoc()):
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<?php
										if ($row['category_id'] == "1") {
											?><td class=""><a href="index.php?page=resultview&start=country&id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></td> <?php
										} elseif ($row['category_id'] == "2") {
											?><td class=""><a href="index.php?page=resultview&start=senate&id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></td> <?php
										}  elseif ($row['category_id'] == "3") {
											?><td class=""><a href="index.php?page=resultview&start=nationalhouse&id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></td> <?php
										} elseif ($row['category_id'] == "4") {
											?><td class=""><a href="index.php?page=resultview&start=state&id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></td> <?php
										} elseif ($row['category_id'] == "5") {
											?><td class=""><a href="index.php?page=resultview&start=statehouse&id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></td> <?php
										} elseif ($row['category_id'] == "6") {
											?><td class=""><a href="index.php?page=resultview&start=lga&id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></td> <?php
										} elseif ($row['category_id'] == "7") {
											?><td class=""><a href="index.php?page=resultview&start=counselor&id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></td> <?php
										} else{
											echo "error detected";
										}
									?>
									<td class=""><?php echo $row['description'] ?></td>
									<?php 
								$vote2 = $conn->query("SELECT * FROM votingcat where id = ".$row['category_id']." order by id asc");
								$row2=$vote2->fetch_assoc();
								?>
									<td class=""><?php echo $row2['name'] ?></td>
									<?php if($row['is_default'] == 1): ?>
										<td class="text-center"><div class="badge badge-success">Yes</div></td>
									<?php elseif($row['is_default'] == 0):  ?>
										<td class="text-center"><div class="badge badge-info update_default" data-id="<?php echo $row['id'] ?>">No</div></td>
									<?php endif; ?>
									<td class="text-center">
										<button class="btn btn-sm btn-primary edit_electionname" type="button" data-id="<?php echo $row['id'] ?>" data-description="<?php echo $row['description'] ?>"  data-title="<?php echo $row['title'] ?>"  data-category_id="<?php echo $row2['id'] ?>" >Edit</button>
										<button class="btn btn-sm btn-danger delete_electionname" type="button" data-id="<?php echo $row['id'] ?>">Delete</button>
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<script>
	$('#manage-electionname').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_electionname',
			method:'POST',
			data:$(this).serialize(),
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})
	$('.edit_electionname').click(function(){
		start_load()
		var cat = $('#manage-electionname')
		var _this = $(this)
		cat.get(0).reset()
		$.ajax({
			url:'ajax.php?action=get_electionname',
			method:'POST',
			data:{id:_this.attr('data-id')},
			success:function(resp){
				if(typeof resp != undefined){
					
					resp = JSON.parse(resp)
					cat.find('[name="id"]').val(_this.attr('data-id'))
					cat.find('[name="category_id"]').val(resp.category_id)
					cat.find('[name="description"]').val(resp.description)
					cat.find('[name="title"]').val(resp.title)
					end_load()
				}
			}
		})
	})
	$('.update_default').click(function(){
		_conf("Are you sure to set this data as default?","update_default",[$(this).attr('data-id')])
		
	})
	$('.delete_electionname').click(function(){
		_conf("Are you sure to delete this data?","delete_electionname",[$(this).attr('data-id')])
	})
	function update_default($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=update_electionname',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp == 1){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)
				}
			}
		})
	}
	function delete_electionname($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_electionname',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp == 1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>