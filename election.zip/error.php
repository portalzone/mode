this first part is the code for the form


			<div class="col-md-12">
				<div class="card">
					<div class="card-body">

									<!-- FORM Panel -->
									<?php
										if ($start == "pollingid") {
											# code...
										
									?>
			<div class="col-md-4">
			<form action=""  method="post" enctype="multipart/form-data">
				<div class="card">
					<div class="card-header">
						    Result Upload Portal
				  	</div>
					<div class="card-body">
					<?php
				}
					?>

										<?php 
			 if ($start == "pollingid") {
			 					$stateid = $_GET['stateid'];
								$lgaid = $_GET['lgaid'];
								$wardid = $_GET['wardid'];
								$pollingid = $_GET['pollingid'];



								$cat6 = $conn->query("SELECT * FROM count where state_id = ".$stateid." and lga_id = ".$lgaid." and ward_id = ".$wardid." and polling_id = ".$pollingid." order by id asc");
								while($row6=$cat6->fetch_assoc()):
									$cat_arr[$row6['id']] = $row6['id'];
								$newid = $row6['party_id'];
								?>

									<?php 

								$cat7 = $conn->query("SELECT * FROM party where id = ".$newid." order by id asc");
								$row7=$cat7->fetch_assoc();
									$cat_arr[$row7['id']] = $row7['id'];
								?>
							<input type="hidden" name="id">
							<input type="hidden" name="stateid" value="<?php echo $stateid;?>">
							<input type="hidden" name="lgaid" value="<?php echo $lgaid;?>">
							<input type="hidden" name="wardid" value="<?php echo $wardid;?>">
							<input type="hidden" name="pollingid" value="<?php echo $pollingid;?>">
							<div class="form-group">
								<label class="control-label"><?php echo $row7['name'] ?></label>
								<input type="text" class="form-control" name="name[]">
							</div>


								<?php
								 endwhile;
						}
		?>
																<?php
										if ($start == "pollingid") {
											# code...
										
									?>
					</div>

							
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button class="btn btn-sm btn-primary col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-sm btn-default col-sm-3" type="button" onclick="$('#manage-result').get(0).reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
			<!-- FORM Panel -->
								
					</div>
				</div>
			</div>
<?php
}
?>




below is the code for the updating


<?php 
			 if ($start == "pollingid") {
			 					$stateid = $_GET['stateid'];
								$lgaid = $_GET['lgaid'];
								$wardid = $_GET['wardid'];
								$pollingid = $_GET['pollingid'];
								$eid = $_GET['id'];

					if (isset($_REQUEST['name'])) {
							echo "Upload sent";

							$name = $_REQUEST['name'];

										foreach($name as $names){

				$data = " vote = '$names' ";
				$data .= ", uploaded = 'yes' ";

									$result6=  $conn->query("UPDATE count set ".$data." where state_id = ".$stateid." and lga_id = ".$lgaid." and ward_id = ".$wardid." and polling_id = ".$pollingid." and electionname = ".$eid."");
				

									
												


												    if($result6){
										 


										           ?>
										  <script>
										  alert('Election Finalized Successfully');
										        window.location.href='index.php?page=manage_electionname&id=<?php echo $id; ?>';
										        </script>
										  <?php
												}

								 } }
					}
				
								?>