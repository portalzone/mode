<?php include('db_connect.php');?>

<?php

	$vote = $conn->query("SELECT * FROM electionname where id=".$_GET['id']);
	foreach ($vote->fetch_array() as $key => $value) {
		$$key= $value;
	}
	$row=$vote->fetch_assoc();
	$idd = $_GET['id'];
	$start = $_GET['start'];


?>

<style>
	.update_default{
		cursor: pointer;
	}
</style>

<?php 
				 if ($start == "pollingid") {


					if (isset($_REQUEST['partyid'])) {
							 					$stateid = $_GET['stateid'];
						$lgaid = $_GET['lgaid'];
						$wardid = $_GET['wardid'];
						$pollingid = $_GET['pollingid'];
						$eid = $_GET['id'];

						$get_needed_count = $conn->query("SELECT * FROM count where state_id = ".$stateid." and lga_id = ".$lgaid." and ward_id = ".$wardid." and polling_id = ".$pollingid." and electionname = ".$id." order by id asc");
						while($row6=$get_needed_count->fetch_assoc()):
							$count_id = $row6['id'];
							$newid = $row6['party_id'];
							$party_vote = $_REQUEST[''.$newid.''];

							$data = " vote = '{$party_vote}' ";
							$data .= ", uploaded = 'yes' ";

							$update_count =  $conn->query("UPDATE count set ".$data." where state_id = ".$stateid." and lga_id = ".$lgaid." and ward_id = ".$wardid." and polling_id = ".$pollingid." and electionname = ".$eid." and party_id = ".$newid."");
							echo $party_vote;
						endwhile;
							if($update_count){  ?>
								  <script>
								  alert('Election Finalized Successfully');
								        window.location.href='index.php?page=resultview&start=ward&stateid=<?php echo $stateid; ?>&lgaid=<?php echo $lgaid; ?>&wardid=<?php echo $wardid; ?>&id=<?php echo $id; ?>';
								        </script>
<?php						}
							
						
					}
				}
								?>
<div class="container-fluid">
	
	<div class="col-lg-12">
		<div class="row">


			<div class="col-md-12">
				<div class="card">
					<div class="card-body">

									<!-- FORM Panel -->
									<?php
										if ($start == "pollingid") {
											# code...
										
									?>
			<div class="col-md-4">
			<form action=""  method="post" enctype="multipart/form-data">
				<div class="card">
					<div class="card-header">
						    Result Upload Portal
				  	</div>
					<div class="card-body">
					<?php
				}
					?>

										<?php 
			 if ($start == "pollingid") {
			 					$stateid = $_GET['stateid'];
								$lgaid = $_GET['lgaid'];
								$wardid = $_GET['wardid'];
								$pollingid = $_GET['pollingid'];
								$id = $_GET['id'];




								$cat6 = $conn->query("SELECT * FROM count where state_id = ".$stateid." and lga_id = ".$lgaid." and ward_id = ".$wardid." and polling_id = ".$pollingid." and electionname = ".$id." order by id asc");
								while($row6=$cat6->fetch_assoc()):
									$cat_arr[$row6['id']] = $row6['id'];
								$newid = $row6['party_id'];
								?>

									<?php 
								$cat7 = $conn->query("SELECT * FROM party where id = ".$newid." order by id asc");
								$row7=$cat7->fetch_assoc();
									$cat_arr[$row7['id']] = $row7['id'];
								?>
							<input type="hidden" name="id">
							<input type="hidden" name="stateid" value="<?php echo $stateid;?>">
							<input type="hidden" name="lgaid" value="<?php echo $lgaid;?>">
							<input type="hidden" name="wardid" value="<?php echo $wardid;?>">
							<input type="hidden" name="pollingid" value="<?php echo $pollingid;?>">
							<input type="hidden" name="partyid" value="<?php echo $newid?>">
							<div class="form-group">
								<label class="control-label"><?php echo $row7['name'] ?></label>
								<input type="text" class="form-control" name="<?=$newid;?>">
							</div>


								<?php
								 endwhile;
						}
		?>
																<?php
										if ($start == "pollingid") {
											# code...
										
									?>
					</div>

							
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button class="btn btn-sm btn-primary col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-sm btn-default col-sm-3" type="button" onclick="$('#manage-result').get(0).reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
			<!-- FORM Panel -->
								
					</div>
				</div>
			</div>
<?php
}
?>
			<!-- Table Panel -->
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table class="table table-bordered table-hover">
							<colgroup>
								<col width="5%">
								<col width="50%">
								<col width="15%">
								<col width="15%">
								<col width="15%">
							</colgroup>
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th class="text-center">Name</th>
									<th class="text-center">Status</th>
									<th class="text-center">Total Votes</th>
									<th class="text-center">Winning Party</th>

								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 1;


														if ($start == "country") {
							$vote1 = $conn->query("SELECT * FROM states order by id asc");
							while($row3=$vote1->fetch_assoc()):
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class=""><a href="index.php?page=resultview&start=state&stateid=<?php echo $row3['id'] ?>&id=<?php echo $idd ?>"><?php echo $row3['name'] ?></a></td>
									<?php
								$vote2 = $conn->query("SELECT * FROM count where electionname = ".$_GET['id']." and state_id = ".$row3['id']." order by id asc");
								$row4=$vote2->fetch_assoc();
								$rowcount = mysqli_num_rows($vote2);

								$result = $conn->query("SELECT SUM(vote) AS value_sum FROM count  where electionname = ".$_GET['id']." and state_id = ".$row3['id'].""); 
								$row8 = mysqli_fetch_assoc($result); 
								$sum = $row8['value_sum'];

								$vote3 = $conn->query("SELECT * FROM count where electionname = ".$_GET['id']." and state_id = ".$row3['id']." and uploaded = 'yes' order by id asc");
								$row5=$vote3->fetch_assoc();
								$rowcount1 = mysqli_num_rows($vote3);
									?>
									<td class=""><?php if ($rowcount == 0) {
											echo "Pending";
									}elseif ($rowcount == $rowcount1) {
											?>
										<div class="badge badge-success">Completed</div>
										<?php
									} else {
										echo $rowcount; ?> / <?php echo $rowcount1; 
										} ?></td>
									<td class=""><?php echo $sum; ?></td>
									<td class="">Winning Party</td>
								</tr>
								<?php endwhile;
						} elseif ($start == "senate") {
							echo "This is a senate election result";
						} elseif ($start == "nationalhouse") {
							echo "This is a national house of assemble election result";
						} elseif ($start == "state") {
								$stateid = $_GET['stateid'];

								$vote1 = $conn->query("SELECT * FROM states WHERE id = ".$stateid." order by id asc");
							while($row3=$vote1->fetch_assoc()):
								
							$vote2 = $conn->query("SELECT * FROM local_governments WHERE state_id = ".$stateid." order by id asc");
							while($row4=$vote2->fetch_assoc()):
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class=""><a href="index.php?page=resultview&start=lga&stateid=<?php echo $row3['id'] ?>&lgaid=<?php echo $row4['id'] ?>&id=<?php echo $idd ?>"><?php echo $row4['name'] ?></a></td>
									<?php
								$vote12 = $conn->query("SELECT * FROM count where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$row4['id']." order by id asc");
								$row14=$vote12->fetch_assoc();
								$rowcount = mysqli_num_rows($vote12);

								$result = $conn->query("SELECT SUM(vote) AS value_sum FROM count  where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$row4['id'].""); 
								$row18 = mysqli_fetch_assoc($result); 
								$sum = $row18['value_sum'];

								$vote13 = $conn->query("SELECT * FROM count where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$row4['id']." and uploaded = 'yes' order by id asc");
								$row15=$vote13->fetch_assoc();
								$rowcount1 = mysqli_num_rows($vote13);
									?>
									<td class=""><?php if ($rowcount == 0) {
											echo "Pending";
									}elseif ($rowcount == $rowcount1) {
											?>
										<div class="badge badge-success">Completed</div>
										<?php
									} else {
										echo $rowcount; ?> / <?php echo $rowcount1; 
										} ?></td>
									<td class=""><?php echo $sum; ?></td>
									<td class="">Party</td>
								</tr>
								<?php endwhile;
								endwhile;
						} elseif ($start == "statehouse") {
							echo "This is a State house of Assembly election result";
						} elseif ($start == "lga") {
								$stateid = $_GET['stateid'];
								$lgaid = $_GET['lgaid'];

								$vote1 = $conn->query("SELECT * FROM states WHERE id = ".$stateid." order by id asc");
							while($row3=$vote1->fetch_assoc()):
								
							$vote2 = $conn->query("SELECT * FROM local_governments WHERE id = ".$lgaid." order by id asc");
							while($row4=$vote2->fetch_assoc()):

							$vote3 = $conn->query("SELECT * FROM ward WHERE lga_id = ".$lgaid." order by id asc");
							while($row5=$vote3->fetch_assoc()):
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class=""><a href="index.php?page=resultview&start=ward&stateid=<?php echo $row3['id'] ?>&lgaid=<?php echo $row4['id'] ?>&wardid=<?php echo $row5['id'] ?>&id=<?php echo $idd ?>"><?php echo $row5['name'] ?></a></td>
									<?php
								$vote12 = $conn->query("SELECT * FROM count where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$_GET['lgaid']." and ward_id = ".$row5['id']." order by id asc");
								$row14=$vote12->fetch_assoc();
								$rowcount = mysqli_num_rows($vote12);

								$result = $conn->query("SELECT SUM(vote) AS value_sum FROM count  where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$_GET['lgaid']." and ward_id = ".$row5['id'].""); 
								$row18 = mysqli_fetch_assoc($result); 
								$sum = $row18['value_sum'];

								$vote13 = $conn->query("SELECT * FROM count where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$_GET['lgaid']." and ward_id = ".$row5['id']." and uploaded = 'yes' order by id asc");
								$row15=$vote13->fetch_assoc();
								$rowcount1 = mysqli_num_rows($vote13);
									?>
									<td class=""><?php if ($rowcount == 0) {
											echo "Pending";
									}elseif ($rowcount == $rowcount1) {
											?>
										<div class="badge badge-success">Completed</div>
										<?php
									} else {
										echo $rowcount; ?> / <?php echo $rowcount1; 
										} ?></td>
									<td class=""><?php echo $sum; ?></td>
									<td class="">Party</td>
								</tr>
								<?php endwhile;
								endwhile; 
								endwhile;
						} elseif ($start == "counselor") {
							echo "This is a Counselorship election result";
						} elseif ($start == "ward") {
							$stateid = $_GET['stateid'];
								$lgaid = $_GET['lgaid'];
								$wardid = $_GET['wardid'];

								$vote1 = $conn->query("SELECT * FROM states WHERE id = ".$stateid." order by id asc");
							while($row3=$vote1->fetch_assoc()):
								
							$vote2 = $conn->query("SELECT * FROM local_governments WHERE id = ".$lgaid." order by id asc");
							while($row4=$vote2->fetch_assoc()):

							$vote3 = $conn->query("SELECT * FROM ward WHERE id = ".$wardid." order by id asc");
							while($row5=$vote3->fetch_assoc()):
							$vote4 = $conn->query("SELECT * FROM polling WHERE ward_id = ".$wardid." order by id asc");
							while($row6=$vote4->fetch_assoc()):
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class=""><a href="index.php?page=resultview&start=pollingid&stateid=<?php echo $row3['id'] ?>&lgaid=<?php echo $row4['id'] ?>&wardid=<?php echo $row5['id'] ?>&pollingid=<?php echo $row6['id'] ?>&id=<?php echo $idd ?>"><?php echo $row6['name'] ?></a></td>

							<?php
								$vote12 = $conn->query("SELECT * FROM count where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$_GET['lgaid']." and ward_id = ".$_GET['wardid']." and polling_id = ".$row6['id']." order by id asc");
								$row14=$vote12->fetch_assoc();
								$rowcount = mysqli_num_rows($vote12);

								$result = $conn->query("SELECT SUM(vote) AS value_sum FROM count  where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$_GET['lgaid']." and ward_id = ".$_GET['wardid']." and polling_id = ".$row6['id'].""); 
								$row18 = mysqli_fetch_assoc($result); 
								$sum = $row18['value_sum'];

								$vote13 = $conn->query("SELECT * FROM count where electionname = ".$_GET['id']." and state_id = ".$_GET['stateid']." and lga_id = ".$_GET['lgaid']." and ward_id = ".$_GET['wardid']." and polling_id = ".$row6['id']." and uploaded = 'yes' order by id asc");
								$row15=$vote13->fetch_assoc();
								$rowcount1 = mysqli_num_rows($vote13);
									?>
									<td class=""><?php if ($rowcount == 0) {
											echo "Pending";
									}elseif ($rowcount == $rowcount1) {
											?>
										<div class="badge badge-success">Completed</div>
										<?php
									} else {
										echo $rowcount; ?> / <?php echo $rowcount1; 
										} ?></td>
									<td class=""><?php echo $sum; ?></td>
									<td class="">Party</td>
								</tr>
								<?php endwhile;
								endwhile; 
								endwhile;
								endwhile;
						} else {
							echo "Unknown Error";
						}

								 ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<script>
	$('#manage-result').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_result',
			method:'POST',
			data:$(this).serialize(),
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})
	$('.edit_result').click(function(){
		start_load()
		var cat = $('#manage-result')
		var _this = $(this)
		cat.get(0).reset()
		$.ajax({
			url:'ajax.php?action=get_result',
			method:'POST',
			data:{id:_this.attr('data-id')},
			success:function(resp){
				if(typeof resp != undefined){
					
					resp = JSON.parse(resp)
					cat.find('[name="id"]').val(_this.attr('data-id'))
					cat.find('[name="name"]').val(resp.name)
					cat.find('[name="stateid"]').val(resp.stateid)
					cat.find('[name="lgaid"]').val(resp.lgaid)
					cat.find('[name="wardid"]').val(resp.wardid)
					cat.find('[name="pollingid"]').val(resp.pollingid)
					end_load()
				}
			}
		})
	})
	$('.update_default').click(function(){
		_conf("Are you sure to set this data as default?","update_default",[$(this).attr('data-id')])
		
	})
	$('.delete_result').click(function(){
		_conf("Are you sure to delete this data?","delete_result",[$(this).attr('data-id')])
	})
	function update_default($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=update_result',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp == 1){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)
				}
			}
		})
	}
	function delete_result($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_result',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp == 1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>