<?php include('db_connect.php');

?>

<div class="container-fluid">
	<?php
	// Fetch State
	$sql = "SELECT * from states order by name";
    $stmt = $conn->prepare($sql); 
    $stmt->execute();
    $result = $stmt->get_result();

    ///
    $sq2 = "SELECT * from lga order by name";
    $stmt2 = $conn->prepare($sq2); 
    $stmt2->execute();
    $result2 = $stmt2->get_result();

    $sq3 = "SELECT * from ward order by name";
    $stmt3 = $conn->prepare($sq3); 
    $stmt3->execute();
    $result3 = $stmt3->get_result();

	?>


	<div class="col-lg-12">
		<div class="row">
			<!-- FORM Panel -->
			<div class="col-md-4">
			<form action="" id="manage-polling">
				<div class="card">
					<div class="card-header">
						    Polling Unit Form
				  	</div>
				  	<div class="card-body">
							<input type="hidden" name="id">
					</div>
					<div class="card-body">
							<div class="form-group">
								<label class="control-label">State</label>
								<select name="state_id" id="country" onchange="getLga(this.value);" class="custom-select browser-default">
								<?php 

								$cat = $conn->query("SELECT * FROM states order by name asc");
								while($row=$cat->fetch_assoc()):
									$cat_arr[$row['id']] = $row['name'];
								
								?>
									<option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
								<?php endwhile; ?>
								</select>
							</div>
								<div class="form-group">
								<label class="control-label">Local Government</label>
								<select name="lga_id" id="state" onchange="getCities(this.value);" class="custom-select browser-default">
								<?php 
								$cat = $conn->query("SELECT * FROM lga order by name asc");
								while($row2=$cat->fetch_assoc()):
									$cat_arr2[$row2['id']] = $row2['name'];
								?>
	        					    <option value="<?php echo $row2['id'] ?>"><?php echo $row2['name'] ?></option>
	        					    <?php endwhile; ?>
	      					   </select>
							</div>
							<div class="form-group">
								<label class="control-label">Ward</label>
								<select name="ward_id" id="city" class="custom-select browser-default">
								<?php 
								$cat = $conn->query("SELECT * FROM ward order by name asc");
								while($row3=$cat->fetch_assoc()):
									$cat_arr3[$row3['id']] = $row3['name'];
								?>
	        					    <option value="<?php echo $row3['id'] ?>"><?php echo $row3['name'] ?></option>
	        					    <?php endwhile; ?>
	      					   </select>

							</div>
						<div class="form-group">
							<label class="control-label">Polling Unit Name</label>
							<input type="text" class="form-control" name="name" >
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button class="btn btn-sm btn-primary col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-sm btn-default col-sm-3" type="button" onclick="$('#manage-polling').get(0).reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
			<!-- FORM Panel -->

			<!-- Table Panel -->
			<div class="col-md-8">
				<div class="card">
					<div class="card-body">
						<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th class="text-center">Local Government Info</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 1;
								$polling = $conn->query("SELECT * FROM polling order by id asc");
								while($row=$polling->fetch_assoc()):

								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class="">
										<p><small>State : <b><?php echo $cat_arr[$row['state_id']] ?></b></small></p>
										<p><small>L.G.A. : <b><?php echo $cat_arr2[$row['lga_id']] ?></b></small></p>
										<p><small>Ward : <b><?php echo $cat_arr3[$row['ward_id']] ?></b></small></p>
										<p><small>Polling Unit : <b><?php echo $row['name'] ?></b></small></p>
									</td>
									<td class="text-center">
										<button class="btn btn-sm btn-primary edit_polling" type="button" data-id="<?php echo $row['id'] ?>" data-name="<?php echo $row['name'] ?>"  data-state_id="<?php echo $row['state_id'] ?>" data-lga_id="<?php echo $row['lga_id'] ?>" data-ward_id="<?php echo $row['ward_id'] ?>"  >Edit</button>
										<button class="btn btn-sm btn-danger delete_polling" type="button" data-id="<?php echo $row['id'] ?>">Delete</button>
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<style>
	
	td{
		vertical-align: middle !important;
	}
	td p{
		margin:unset;
	}
</style>
<script>
	$(document).ready(function(){
		$('table').dataTable(
		{
			"lengthMenu":[[10, 25, 50, -1], [10, 25, 50, "All"]]
		});
	});
	$('#manage-polling').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_polling',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})
	$('.edit_polling').click(function(){
		start_load()
		var cat = $('#manage-polling')
		cat.get(0).reset()
		cat.find("[name='id']").val($(this).attr('data-id'))
		cat.find("[name='name']").val($(this).attr('data-name'))
		cat.find("[name='state_id']").val($(this).attr('data-state_id'))
		cat.find("[name='lga_id']").val($(this).attr('data-lga_id'))
		cat.find("[name='ward_id']").val($(this).attr('data-ward_id'))
		end_load()
	})
	$('.delete_polling').click(function(){
		_conf("Are you sure to delete this Polling Unit?","delete_polling",[$(this).attr('data-id')])
	})
	function delete_polling($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_polling',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>

	<script type="text/javascript">
		
		function getLga(state_id){
			
			// Empty the dropdown
			var stateel = document.getElementById('state');
			var cityel = document.getElementById('city');
			
			stateel.innerHTML = "";
			cityel.innerHTML = "";

			var stateopt = document.createElement('option');
			stateopt.value = 0;
			stateopt.innerHTML = '-- Select State --';
			stateel.appendChild(stateopt);

			var cityopt = document.createElement('option');
			cityopt.value = 0;
			cityopt.innerHTML = '-- Select City --';
			cityel.appendChild(cityopt);

		    // AJAX request
		    var xhttp = new XMLHttpRequest();
			xhttp.open("POST", "ajaxfile.php", true); 
			xhttp.setRequestHeader("Content-Type", "application/json");
			xhttp.onreadystatechange = function() {
			   	if (this.readyState == 4 && this.status == 200) {
			     	// Response
			     	var response = JSON.parse(this.responseText);
			     	
			     	var len = 0;
		            if(response != null){
		               len = response.length;
		            }
		           
		            if(len > 0){
		               	// Read data and create <option >
		               	for(var i=0; i<len; i++){

		                  	var id = response[i].id;
		                  	var name = response[i].name;

		                  	// Add option to state dropdown
		                  	var opt = document.createElement('option');
						    opt.value = id;
						    opt.innerHTML = name;
						    stateel.appendChild(opt);

		               	}
		            }
			   	}
			};
			var data = {request:'getLga',state_id: state_id};
			xhttp.send(JSON.stringify(data));
		    
		}

		function getCities(state_id){

			// Empty the dropdown
			var cityel = document.getElementById('city');
			
			cityel.innerHTML = "";

			var cityopt = document.createElement('option');
			cityopt.value = 0;
			cityopt.innerHTML = '-- Select City --';
			cityel.appendChild(cityopt);

		    // AJAX request
		    var xhttp = new XMLHttpRequest();
			xhttp.open("POST", "ajaxfile.php", true); 
			xhttp.setRequestHeader("Content-Type", "application/json");
			xhttp.onreadystatechange = function() {
			   	if (this.readyState == 4 && this.status == 200) {
			     	// Response
			     	var response = JSON.parse(this.responseText);
			     	
			     	var len = 0;
		            if(response != null){
		               len = response.length;
		            }
		           
		            if(len > 0){
		               	// Read data and create <option >
		               	for(var i=0; i<len; i++){

		                  	var id = response[i].id;
		                  	var name = response[i].name;

		                  	// Add option to city dropdown
		                  	var opt = document.createElement('option');
						    opt.value = id;
						    opt.innerHTML = name;
						    cityel.appendChild(opt);

		               	}
		            }
			   	}
			};
			var data = {request:'getCities',state_id: state_id};
			xhttp.send(JSON.stringify(data));
		}
	</script>
