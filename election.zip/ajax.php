<?php
ob_start();
$action = $_GET['action'];
include 'admin_class.php';
$crud = new Action();

if($action == 'login'){
	$login = $crud->login();
	if($login)
		echo $login;
}
if($action == 'login2'){
	$login = $crud->login2();
	if($login)
		echo $login;
}
if($action == 'logout'){
	$logout = $crud->logout();
	if($logout)
		echo $logout;
}
if($action == 'logout2'){
	$logout = $crud->logout2();
	if($logout)
		echo $logout;
}
if($action == 'save_user'){
	$save = $crud->save_user();
	if($save)
		echo $save;
}
if($action == 'delete_user'){
	$save = $crud->delete_user();
	if($save)
		echo $save;
}
if($action == 'signup'){
	$save = $crud->signup();
	if($save)
		echo $save;
}
if($action == "save_settings"){
	$save = $crud->save_settings();
	if($save)
		echo $save;
}
if($action == "save_states"){
	$save = $crud->save_states();
	if($save)
		echo $save;
}
if($action == "delete_states"){
	$save = $crud->delete_states();
	if($save)
		echo $save;
}
if($action == "save_votingcat"){
	$save = $crud->save_votingcat();
	if($save)
		echo $save;
}
if($action == "delete_votingcat"){
	$save = $crud->delete_votingcat();
	if($save)
		echo $save;
}
if($action == "save_party"){
	$save = $crud->save_party();
	if($save)
		echo $save;
}
if($action == "delete_party"){
	$save = $crud->delete_party();
	if($save)
		echo $save;
}

if($action == "save_ward"){
	$save = $crud->save_ward();
	if($save)
		echo $save;
}
if($action == "delete_ward"){
	$save = $crud->delete_ward();
	if($save)
		echo $save;
}
if($action == "save_lga"){
	$save = $crud->save_lga();
	if($save)
		echo $save;
}
if($action == "delete_lga"){
	$save = $crud->delete_lga();
	if($save)
		echo $save;
}
if($action == "save_selectstate"){
	$save = $crud->save_selectstate();
	if($save)
		echo $save;
}
if($action == "save_selectlga"){
	$save = $crud->save_selectlga();
	if($save)
		echo $save;
}
if($action == "save_contesting"){
	$save = $crud->save_contesting();
	if($save)
		echo $save;
}
if($action == "save_polling"){
	$save = $crud->save_polling();
	if($save)
		echo $save;
}
if($action == "delete_polling"){
	$save = $crud->delete_polling();
	if($save)
		echo $save;
}
if($action == "save_receiving"){
	$save = $crud->save_receiving();
	if($save)
		echo $save;
}
if($action == "delete_receiving"){
	$save = $crud->delete_receiving();
	if($save)
		echo $save;
}
if($action == "save_customer"){
	$save = $crud->save_customer();
	if($save)
		echo $save;
}
if($action == "delete_customer"){
	$save = $crud->delete_customer();
	if($save)
		echo $save;
}

if($action == "chk_prod_availability"){
	$save = $crud->chk_prod_availability();
	if($save)
		echo $save;
}

if($action == "save_sales"){
	$save = $crud->save_sales();
	if($save)
		echo $save;
}

if($action == "delete_sales"){
	$save = $crud->delete_sales();
	if($save)
		echo $save;
}

if($action == 'save_electionname'){
	$save = $crud->save_electionname();
	if($save)
		echo $save;
}
if($action == 'get_electionname'){
	$get = $crud->get_electionname();
	if($get)
		echo $get;
}
if($action == 'update_electionname'){
	$update = $crud->update_electionname();
	if($update)
		echo $update;
}
if($action == 'delete_electionname'){
	$delete = $crud->delete_electionname();
	if($delete)
		echo $delete;
}

if($action == 'save_result'){
	$save = $crud->save_result();
	if($save)
		echo $save;
}
if($action == 'get_result'){
	$get = $crud->get_result();
	if($get)
		echo $get;
}
if($action == 'update_result'){
	$update = $crud->update_result();
	if($update)
		echo $update;
}
if($action == 'delete_result'){
	$delete = $crud->delete_result();
	if($delete)
		echo $delete;
}
