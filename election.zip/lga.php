<?php include('db_connect.php');

?>

<div class="container-fluid">
	
	<div class="col-lg-12">
		<div class="row">
			<!-- FORM Panel -->
			<div class="col-md-4">
			<form action="" id="manage-lga">
				<div class="card">
					<div class="card-header">
						    Local Government Form
				  	</div>
				  	<div class="card-body">
							<input type="hidden" name="id">
					</div>
					<div class="card-body">
							<div class="form-group">
								<label class="control-label">State</label>
								<select name="state_id" id="" class="custom-select browser-default">
								<?php 

								$cat = $conn->query("SELECT * FROM states order by name asc");
								while($row=$cat->fetch_assoc()):
									$cat_arr[$row['id']] = $row['name'];
								?>
									<option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
								<?php endwhile; ?>
								</select>
							</div>
						<div class="form-group">
							<label class="control-label">Local Government Name</label>
							<input type="text" class="form-control" name="name" >
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button class="btn btn-sm btn-primary col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-sm btn-default col-sm-3" type="button" onclick="$('#manage-lga').get(0).reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
			<!-- FORM Panel -->

			<!-- Table Panel -->
			<div class="col-md-8">
				<div class="card">
					<div class="card-body">
						<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th class="text-center">Local Government Info</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 1;
								$lga = $conn->query("SELECT * FROM lga order by id asc");
								while($row=$lga->fetch_assoc()):
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class="">
										<p><small>State : <b><?php echo $cat_arr[$row['state_id']] ?></b></small></p>
										<p><small>L.G.A. : <b><?php echo $row['name'] ?></b></small></p>
									</td>
									<td class="text-center">
										<button class="btn btn-sm btn-primary edit_lga" type="button" data-id="<?php echo $row['id'] ?>" data-name="<?php echo $row['name'] ?>"  data-state_id="<?php echo $row['state_id'] ?>" >Edit</button>
										<button class="btn btn-sm btn-danger delete_lga" type="button" data-id="<?php echo $row['id'] ?>">Delete</button>
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<style>
	
	td{
		vertical-align: middle !important;
	}
	td p{
		margin:unset;
	}
</style>
<script>
	$(document).ready(function(){
		$('table').dataTable(
		{
			"lengthMenu":[[10, 25, 50, -1], [10, 25, 50, "All"]]
		});
	});
	$('#manage-lga').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_lga',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})
	$('.edit_lga').click(function(){
		start_load()
		var cat = $('#manage-lga')
		cat.get(0).reset()
		cat.find("[name='id']").val($(this).attr('data-id'))
		cat.find("[name='name']").val($(this).attr('data-name'))
		cat.find("[name='state_id']").val($(this).attr('data-state_id'))
		end_load()
	})
	$('.delete_lga').click(function(){
		_conf("Are you sure to delete this lga?","delete_lga",[$(this).attr('data-id')])
	})
	function delete_lga($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_lga',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>