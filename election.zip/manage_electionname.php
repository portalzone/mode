<?php include('db_connect.php');?>
<?php

	$vote = $conn->query("SELECT * FROM electionname where id=".$_GET['id']);
	foreach ($vote->fetch_array() as $key => $value) {
		$$key= $value;
	}
	$idd = $_GET['id'];


?>
<style>
	.candidate {
	    margin: auto;
	    width: 16vw;
	    padding: 10px;
	    cursor: pointer;
	    border-radius: 3px;
	    margin-bottom: 1em
	}
	.candidate:hover {
	    background-color: #80808030;
	    box-shadow: 2.5px 3px #00000063;
	}
	.candidate img {
	    height: 14vh;
	    width: 8vw;
	    margin: auto;
	}
	span.rem_btn {
	    position: absolute;
	    right: 0;
	    top: -1em;
	    z-index: 10
	}
</style>


<div class="container-fluid">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-body">
				<div class="col-lg-12">
					<div class="text-center">
						<h3><b><?php echo $title ?></b></h3>
						<small><b><?php echo $description; ?></b></small>	
					</div>
					Election Type: <?php 
						$cats = $conn->query("SELECT * FROM votingcat where id = ".$category_id." order by id asc");
						$row2=$cats->fetch_assoc();
						 echo $row2['name'] ?>
					<hr>
					<p><h5 class="text-center">Election Summary</h5></p>

					<hr> 
					<p><h5>Contesting Parties</h5></p>
								<?php 

								$cat6 = $conn->query("SELECT * FROM contesting where election_id = ".$idd." order by id asc");
								while($row6=$cat6->fetch_assoc()):
									$cat_arr[$row6['id']] = $row6['id'];
								$newid = $row6['party_id'];
								?>

									<?php 

								$cat7 = $conn->query("SELECT * FROM party where id = ".$newid." order by id asc");
								$row7=$cat7->fetch_assoc();
									$cat_arr[$row7['id']] = $row7['id'];
								?><b>
									<?php echo $row7['name'] ?></b>
									 <br>
								
								<?php endwhile; ?>
					<hr>
					<?php 
						if($start == "yes") {
							echo "Election created";
						} elseif ($start == "no" && $category_id == "1") {
							echo "Election not Created";
							?>
							<a href="index.php?page=manage_electionname&id=<?php echo $id; ?>&action=create">Create this election</a>
								<?php

									if (isset($_REQUEST['action'])){

										$query = "INSERT INTO votes (`state`, `lga`, `ward`, `polling`, `votemade`, `votecat`, `electionname`)
										SELECT state_id, lga_id, ward_id, id, '0', ".$category_id.", ".$id."  FROM `polling` order by 'id'";

										$query1 = "UPDATE electionname set start = 'yes' where id= ".$id." ";
										$result1 = mysqli_query($conn,$query1);
												$result = mysqli_query($conn,$query);



												$cat4 = $conn->query("SELECT * FROM contesting where election_id = ".$id." order by id asc");
										$row4=$cat4->fetch_assoc();

										 $query2 = "INSERT INTO count (`state_id`, `lga_id`, `ward_id`, `polling_id`, `party_id`, `electionname`)
										SELECT state_id, lga_id, ward_id, id, ".$row4['party_id'].", ".$id."  FROM `polling` order by 'id'";



								$cat4 = $conn->query("SELECT * FROM contesting where election_id = ".$id." order by id asc");
								while($row4=$cat4->fetch_assoc()):
									$cat_arr[$row4['id']] = $row4['id'];
								
								
								 $query2 = "INSERT INTO count (`state_id`, `lga_id`, `ward_id`, `polling_id`, `party_id`, `electionname`, `uploaded`)
										SELECT state_id, lga_id, ward_id, id, ".$row4['party_id'].", ".$id.", 'no'  FROM `polling` order by 'id'";

												$result2 = mysqli_query($conn,$query2);

								endwhile;

										        if($result){
										 


										           ?>
										  <script>
										  alert('Election Finalized Successfully');
										        window.location.href='index.php?page=manage_electionname&id=<?php echo $id; ?>';
										        </script>
										  <?php
												}
								
									}
								
						} elseif ($start == "no" && $category_id == "4") {
							echo "Election not Created";
							?>
							<a href="index.php?page=manage_electionname&id=<?php echo $id; ?>&action=create">Create this election</a>
								<?php

									if (isset($_REQUEST['action'])){

										$query = "INSERT INTO votes (`state`, `lga`, `ward`, `polling`, `votemade`, `votecat`, `electionname`)
										SELECT state_id, lga_id, ward_id, id, '0', ".$category_id.", ".$id."  FROM `polling` WHERE state_id = ".$state_id."  order by 'id'";

										$query1 = "UPDATE electionname set start = 'yes' where id= ".$id." ";
										$result1 = mysqli_query($conn,$query1);


												$result = mysqli_query($conn,$query);
										        if($result){
										           ?>
										  <script>
										  alert('Election Finalized Successfully');
										        window.location.href='index.php?page=manage_electionname&id=<?php echo $id; ?>';
										        </script>
										  <?php
												}
								
									}
						}

						elseif ($start == "no" && $category_id == "6") {
							echo "Election not Created";
							?>
							<a href="index.php?page=manage_electionname&id=<?php echo $id; ?>&action=create">Create this election</a>
								<?php

									if (isset($_REQUEST['action'])){

										$query = "INSERT INTO votes (`state`, `lga`, `ward`, `polling`, `votemade`, `votecat`, `electionname`)
										SELECT state_id, lga_id, ward_id, id, '0', ".$category_id.", ".$id."  FROM `polling` WHERE lga_id = ".$lga_id."  order by 'id'";

										$query1 = "UPDATE electionname set start = 'yes' where id= ".$id." ";
										$result1 = mysqli_query($conn,$query1);


												$result = mysqli_query($conn,$query);
										        if($result){
										           ?>
										  <script>
										  alert('Election Finalized Successfully');
										        window.location.href='index.php?page=manage_electionname&id=<?php echo $id; ?>';
										        </script>
										  <?php
												}
								
									}
						}


						else {
							echo "Election Running or Cannot start election";
						}
					?> 
					<hr>
					<?php 
					if ($category_id=="1") {
						$cat3 = $conn->query("SELECT * FROM polling order by id asc");
						$row3=$cat3->fetch_assoc();
						$rowcount = mysqli_num_rows($cat3);

						$cat4 = $conn->query("SELECT * FROM ward order by id asc");
						$row4=$cat4->fetch_assoc();
						$rowcount4 = mysqli_num_rows($cat4);

						$cat5 = $conn->query("SELECT * FROM local_governments order by id asc");
						$row5=$cat5->fetch_assoc();
						$rowcount5 = mysqli_num_rows($cat5);

						$cat6 = $conn->query("SELECT * FROM states order by id asc");
						$row6=$cat6->fetch_assoc();
						$rowcount6 = mysqli_num_rows($cat6);

						echo "Number Of States: "; echo $rowcount6; ?> <br> <?php
						echo "Number Of Local Governments: "; echo $rowcount5; ?> <br> <?php
						echo "Number Of Wards: "; echo $rowcount4; ?> <br> <?php
						echo "Number Of Polling Units: "; echo $rowcount;?>

						<?php 
					}
					elseif ($category_id=="2") {
						echo "Senatorial Election";
					}
					elseif ($category_id=="3") {
						echo "National Assemble Election";
					}
					elseif ($category_id=="4") {
						if (!$state_id) {
							?>
							<!-- FORM Panel -->
			<div class="col-md-6">
			<form action="" id="manage-selectstate">
				<div class="card">
					<div class="card-header">
						    Select state where election would hold
				  	</div>
							<input type="hidden" name="id" value="<?php echo $idd ?>">
					<div class="card-body">
							<div class="form-group">
								<label class="control-label">State</label>
								<select name="state_id" id="" class="custom-select browser-default">
								<?php 

								$cat = $conn->query("SELECT * FROM states order by name asc");
								while($row=$cat->fetch_assoc()):
									$cat_arr[$row['id']] = $row['name'];
								?>
									<option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
								<?php endwhile; ?>
								</select>
							</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button class="btn btn-sm btn-primary col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-sm btn-default col-sm-3" type="button" onclick="$('#manage-selectstate').get(0).reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
							<?php
						} else {
						$cat3 = $conn->query("SELECT * FROM polling where state_id = $state_id order by id asc");
						$row3=$cat3->fetch_assoc();
						$rowcount = mysqli_num_rows($cat3);

						$cat4 = $conn->query("SELECT * FROM ward where state_id = $state_id order by id asc");
						$row4=$cat4->fetch_assoc();
						$rowcount4 = mysqli_num_rows($cat4);

						$cat5 = $conn->query("SELECT * FROM local_governments where state_id = $state_id order by id asc");
						$row5=$cat5->fetch_assoc();
						$rowcount5 = mysqli_num_rows($cat5);

						echo "Number Of Local Governments: "; echo $rowcount5; ?> <br> <?php
						echo "Number Of Wards: "; echo $rowcount4; ?> <br> <?php
						echo "Number Of Polling Units: "; echo $rowcount;?>

						<?php
						}
					}
					elseif ($category_id=="5") {
						echo "State House of Assembly Election";
					}
					elseif ($category_id=="6") {
						if (!$lga_id) {
							?>
										<!-- FORM Panel -->
			<div class="col-md-6">
			<form action="" id="manage-selectlga">
				<div class="card">
					<div class="card-header">
						    Select Local Government where election would hold
				  	</div>
							<input type="hidden" name="id" value="<?php echo $idd ?>">
					<div class="card-body">
							<div class="form-group">
								<label class="control-label">State</label>
								<select name="state_id" id="country" onchange="getLga(this.value);" class="custom-select browser-default">
								<?php 

								$cat = $conn->query("SELECT * FROM states order by name asc");
								while($row=$cat->fetch_assoc()):
									$cat_arr[$row['id']] = $row['name'];
								
								?>
									<option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
								<?php endwhile; ?>

								
								</select>
							</div>
								<div class="form-group">
								<label class="control-label">Local Government</label>
								<select name="lga_id" id="state" onchange="getCities(this.value);" class="custom-select browser-default">
								<?php 

								$cat = $conn->query("SELECT * FROM lga order by name asc");
								while($row2=$cat->fetch_assoc()):
									$cat_arr2[$row2['id']] = $row2['name'];
								
								?>
	        					    <option value="<?php echo $row2['id'] ?>"><?php echo $row2['name'] ?></option>
	        					    <?php endwhile; ?>
	      					   </select>
							</div>
						<div class="form-group">
<!--							<label class="control-label">Ward Name</label>-->
							<input type="hidden" id="city" class="form-control" name="name" >
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button class="btn btn-sm btn-primary col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-sm btn-default col-sm-3" type="button" onclick="$('#manage-selectlga').get(0).reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
			<!-- FORM Panel -->

							<?php
						} else {
						$cat3 = $conn->query("SELECT * FROM polling where lga_id = $lga_id order by id asc");
						$row3=$cat3->fetch_assoc();
						$rowcount = mysqli_num_rows($cat3);

						$cat4 = $conn->query("SELECT * FROM ward where lga_id = $lga_id order by id asc");
						$row4=$cat4->fetch_assoc();
						$rowcount4 = mysqli_num_rows($cat4);

						echo "Number Of Wards: "; echo $rowcount4; ?> <br> <?php
						echo "Number Of Polling Units: "; echo $rowcount;?>
						
						<?php
						}

					}
					elseif ($category_id=="7") {
						echo "Counselor Election";
					} 
					else
					{
						echo "Other Election";
					}
					 ?>

					 <hr>
						<p><h5> Contesting Parties </h5></p>
							<!-- FORM Panel -->
			<div class="col-md-6">
			<form action="" id="manage-contesting">
				<div class="card">
					<div class="card-header">
						    Select party that are elegible to contest this election
				  	</div>
							<input type="hidden" name="id" value="<?php echo $idd ?>">
					<div class="card-body">
							<div class="form-group">
								<label class="control-label">State</label>
								<select name="party_id" id="" class="custom-select browser-default">
								<?php 

								$cat5 = $conn->query("SELECT * FROM party order by name asc");
								while($row5=$cat5->fetch_assoc()):
									$cat_arr[$row5['id']] = $row5['name'];
									$party = $row5['id'];
								?>
									<option value="<?php echo $row5['id'] ?>"><?php echo $row5['name'] ?></option>
								<?php endwhile; ?>
								</select>
							</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button class="btn btn-sm btn-primary col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-sm btn-default col-sm-3" type="button" onclick="$('#manage-contesting').get(0).reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
<!-- Form Panel End -->
			

					<hr>
					<div class="row">
						<div class="col-md-12">
							<button class="btn btn-sm btn-primary float-right" type="button" id="new_opt">New Candidate</button>
						</div>
					</div>














				</div>
				
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function(){
		$('table').dataTable(
		{
			"lengthMenu":[[10, 25, 50, -1], [10, 25, 50, "All"]]
		});
	});
	$('#manage-selectstate').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_selectstate',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})

</script>

<script>
	$(document).ready(function(){
		$('table').dataTable(
		{
			"lengthMenu":[[10, 25, 50, -1], [10, 25, 50, "All"]]
		});
	});
	$('#manage-contesting').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_contesting',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})

</script>


<script>
	$(document).ready(function(){
		$('table').dataTable(
		{
			"lengthMenu":[[10, 25, 50, -1], [10, 25, 50, "All"]]
		});
	});
	$('#manage-selectlga').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_selectlga',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})

</script>



	<script type="text/javascript">
		
		function getLga(state_id){
			
			// Empty the dropdown
			var stateel = document.getElementById('state');
			var cityel = document.getElementById('city');
			
			stateel.innerHTML = "";
			cityel.innerHTML = "";

			var stateopt = document.createElement('option');
			stateopt.value = 0;
			stateopt.innerHTML = '-- Select State --';
			stateel.appendChild(stateopt);

			var cityopt = document.createElement('option');
			cityopt.value = 0;
			cityopt.innerHTML = '-- Select City --';
			cityel.appendChild(cityopt);

		    // AJAX request
		    var xhttp = new XMLHttpRequest();
			xhttp.open("POST", "ajaxfile.php", true); 
			xhttp.setRequestHeader("Content-Type", "application/json");
			xhttp.onreadystatechange = function() {
			   	if (this.readyState == 4 && this.status == 200) {
			     	// Response
			     	var response = JSON.parse(this.responseText);
			     	
			     	var len = 0;
		            if(response != null){
		               len = response.length;
		            }
		           
		            if(len > 0){
		               	// Read data and create <option >
		               	for(var i=0; i<len; i++){

		                  	var id = response[i].id;
		                  	var name = response[i].name;

		                  	// Add option to state dropdown
		                  	var opt = document.createElement('option');
						    opt.value = id;
						    opt.innerHTML = name;
						    stateel.appendChild(opt);

		               	}
		            }
			   	}
			};
			var data = {request:'getLga',state_id: state_id};
			xhttp.send(JSON.stringify(data));
		    
		}

		function getCities(state_id){

			// Empty the dropdown
			var cityel = document.getElementById('city');
			
			cityel.innerHTML = "";

			var cityopt = document.createElement('option');
			cityopt.value = 0;
			cityopt.innerHTML = '-- Select City --';
			cityel.appendChild(cityopt);

		    // AJAX request
		    var xhttp = new XMLHttpRequest();
			xhttp.open("POST", "ajaxfile.php", true); 
			xhttp.setRequestHeader("Content-Type", "application/json");
			xhttp.onreadystatechange = function() {
			   	if (this.readyState == 4 && this.status == 200) {
			     	// Response
			     	var response = JSON.parse(this.responseText);
			     	
			     	var len = 0;
		            if(response != null){
		               len = response.length;
		            }
		           
		            if(len > 0){
		               	// Read data and create <option >
		               	for(var i=0; i<len; i++){

		                  	var id = response[i].id;
		                  	var name = response[i].name;

		                  	// Add option to city dropdown
		                  	var opt = document.createElement('option');
						    opt.value = id;
						    opt.innerHTML = name;
						    cityel.appendChild(opt);

		               	}
		            }
			   	}
			};
			var data = {request:'getCities',state_id: state_id};
			xhttp.send(JSON.stringify(data));
		}
	</script>
